#!/bin/bash

set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MAIN_SCRIPT="$SCRIPT_DIR/Enable-CodexWM.sh"

clear
printf '%s\n' '========================================'
printf '%s\n' '   Codex WM 模型一键配置工具（macOS）'
printf '%s\n' '========================================'
printf '\n'
printf '%s\n' '   1. 添加 gpt-5.6-sol-wm'
printf '%s\n' '   2. 取消 gpt-5.6-sol-wm'
printf '\n'
printf '%s\n' '========================================'
printf '请选择 [1/2]: '
IFS= read -r choice

if [ ! -x "$MAIN_SCRIPT" ]; then
    printf '\n[失败] 找不到可执行脚本：%s\n' "$MAIN_SCRIPT"
elif [ "$choice" = '1' ]; then
    printf '\n'
    "$MAIN_SCRIPT" --add
elif [ "$choice" = '2' ]; then
    printf '\n'
    "$MAIN_SCRIPT" --remove
else
    printf '\n[失败] 无效选项：%s\n' "$choice"
fi

printf '\n按 Return 键关闭窗口...'
IFS= read -r _
