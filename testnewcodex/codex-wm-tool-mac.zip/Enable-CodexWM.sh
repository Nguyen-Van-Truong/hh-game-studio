#!/bin/bash

set -u
set -o pipefail

export PATH="/opt/homebrew/bin:/usr/local/bin:$HOME/.local/bin:$PATH"
export LC_ALL=C

WM_SLUG='gpt-5.6-sol-wm'
SOURCE_SLUG='gpt-5.6-sol'
AUTO_SLUG='codex-auto-review'
ROLLBACK=0
CODEX_HOME_ARG=''

write_step() { printf '\n\033[36m==> %s\033[0m\n' "$1"; }
write_ok()   { printf '  \033[32m[OK] %s\033[0m\n' "$1"; }
write_warn() { printf '  \033[33m[!!] %s\033[0m\n' "$1"; }
fail()       { printf '\n\033[31m[失败] %s\033[0m\n' "$1" >&2; exit 1; }

usage() {
    cat <<'EOF'
用法：
  ./Enable-CodexWM.sh [--codex-home PATH] --add
  ./Enable-CodexWM.sh [--codex-home PATH] --remove

选项：
  --codex-home PATH  指定 CODEX_HOME（默认读取环境变量或 ~/.codex）
  --add              添加 gpt-5.6-sol-wm（默认）
  --remove           取消 gpt-5.6-sol-wm 并恢复配置
  -h, --help         显示帮助
EOF
}

while [ "$#" -gt 0 ]; do
    case "$1" in
        --codex-home)
            [ "$#" -ge 2 ] || fail '--codex-home 后缺少路径。'
            CODEX_HOME_ARG=$2
            shift 2
            ;;
        --add)
            ROLLBACK=0
            shift
            ;;
        --remove|--rollback)
            ROLLBACK=1
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            fail "未知参数：$1"
            ;;
    esac
done

if [ -n "$CODEX_HOME_ARG" ]; then
    CODEX_HOME_DIR=$CODEX_HOME_ARG
elif [ -n "${CODEX_HOME:-}" ]; then
    CODEX_HOME_DIR=$CODEX_HOME
else
    CODEX_HOME_DIR="$HOME/.codex"
fi

CATALOG_PATH="$CODEX_HOME_DIR/models_wm_visible.json"
CONFIG_PATH="$CODEX_HOME_DIR/config.toml"

[ -d "$CODEX_HOME_DIR" ] || fail "找不到 CODEX_HOME：$CODEX_HOME_DIR
请先安装并登录 Codex。"
write_step "CODEX_HOME = $CODEX_HOME_DIR"

top_level_line() {
    file=$1
    key=$2
    /usr/bin/awk -v wanted="$key" '
        /^[[:space:]]*\[/ { exit }
        {
            line = $0
            sub(/^[[:space:]]*/, "", line)
            if (line ~ ("^" wanted "[[:space:]]*=")) {
                print $0
                found = 1
                exit
            }
        }
        END { if (!found) exit 1 }
    ' "$file"
}

restore_config() {
    write_step "取消 $WM_SLUG"
    [ -f "$CONFIG_PATH" ] || fail "config.toml 不存在：$CONFIG_PATH"

    backup=$(/usr/bin/find "$CODEX_HOME_DIR" -maxdepth 1 -type f \
        -name 'config.toml.before-wm-mac-*.bak' -print 2>/dev/null | \
        /usr/bin/sort | /usr/bin/head -n 1)
    [ -n "$backup" ] || fail '没有找到 macOS 版创建的配置备份，无法安全自动回滚。'

    old_model=''
    old_catalog=''
    old_effort=''
    has_model=0
    has_catalog=0
    has_effort=0
    if old_model=$(top_level_line "$backup" 'model'); then has_model=1; fi
    if old_catalog=$(top_level_line "$backup" 'model_catalog_json'); then has_catalog=1; fi
    if old_effort=$(top_level_line "$backup" 'model_reasoning_effort'); then has_effort=1; fi

    tmp_config=$(/usr/bin/mktemp "$CODEX_HOME_DIR/.config.toml.wm-rollback.XXXXXX") || \
        fail '无法创建临时配置文件。'
    trap 'rm -f "${tmp_config:-}"' EXIT

    WM_HAS_MODEL=$has_model \
    WM_HAS_CATALOG=$has_catalog \
    WM_HAS_EFFORT=$has_effort \
    WM_MODEL_LINE=$old_model \
    WM_CATALOG_LINE=$old_catalog \
    WM_EFFORT_LINE=$old_effort \
    /usr/bin/awk '
        function emit_missing() {
            if (ENVIRON["WM_HAS_MODEL"] == "1" && !seen_model) print ENVIRON["WM_MODEL_LINE"]
            if (ENVIRON["WM_HAS_CATALOG"] == "1" && !seen_catalog) print ENVIRON["WM_CATALOG_LINE"]
            if (ENVIRON["WM_HAS_EFFORT"] == "1" && !seen_effort) print ENVIRON["WM_EFFORT_LINE"]
        }
        BEGIN { in_top = 1 }
        in_top && /^[[:space:]]*\[/ {
            emit_missing()
            in_top = 0
        }
        in_top {
            line = $0
            sub(/^[[:space:]]*/, "", line)
            if (line ~ /^model[[:space:]]*=/) {
                if (!seen_model && ENVIRON["WM_HAS_MODEL"] == "1") print ENVIRON["WM_MODEL_LINE"]
                seen_model = 1
                next
            }
            if (line ~ /^model_catalog_json[[:space:]]*=/) {
                if (!seen_catalog && ENVIRON["WM_HAS_CATALOG"] == "1") print ENVIRON["WM_CATALOG_LINE"]
                seen_catalog = 1
                next
            }
            if (line ~ /^model_reasoning_effort[[:space:]]*=/) {
                if (!seen_effort && ENVIRON["WM_HAS_EFFORT"] == "1") print ENVIRON["WM_EFFORT_LINE"]
                seen_effort = 1
                next
            }
        }
        { print }
        END { if (in_top) emit_missing() }
    ' "$CONFIG_PATH" > "$tmp_config" || fail '生成回滚配置失败。'

    /bin/mv -f "$tmp_config" "$CONFIG_PATH" || fail '写入回滚配置失败。'
    trap - EXIT
    write_ok "已参考备份回滚：$(basename "$backup")"
    write_ok '自定义模型目录和备份文件已保留，便于检查。'
    printf '\n\033[36m已取消。请彻底退出并重启 Codex。\033[0m\n'
}

if [ "$ROLLBACK" -eq 1 ]; then
    restore_config
    exit 0
fi

if [ -x "$HOME/.local/bin/codex" ]; then
    CODEX_BIN="$HOME/.local/bin/codex"
elif command -v codex >/dev/null 2>&1; then
    CODEX_BIN=$(command -v codex)
elif [ -x '/opt/homebrew/bin/codex' ]; then
    CODEX_BIN='/opt/homebrew/bin/codex'
elif [ -x '/usr/local/bin/codex' ]; then
    CODEX_BIN='/usr/local/bin/codex'
else
    fail '找不到 codex 命令。'
fi

write_step '生成自定义模型目录'
stamp=$(/bin/date '+%Y%m%d-%H%M%S')
bundled_catalog=$(/usr/bin/mktemp "${TMPDIR:-/tmp}/codex-wm-bundled.XXXXXX") || \
    fail '无法创建临时模型目录。'
bundled_error="$bundled_catalog.err"
if ! "$CODEX_BIN" debug models --bundled > "$bundled_catalog" 2> "$bundled_error"; then
    bundled_message=$(/usr/bin/sed -n '1,8p' "$bundled_error")
    fail "无法读取 Codex 内置模型目录：$bundled_message"
fi
if [ -f "$CATALOG_PATH" ]; then
    /bin/cp -p "$CATALOG_PATH" "$CATALOG_PATH.before-$stamp.bak" || \
        fail '备份已有自定义模型目录失败。'
fi
/bin/cp -p "$bundled_catalog" "$CATALOG_PATH" || fail '创建自定义模型目录失败。'

jxa_output=$(/usr/bin/osascript -l JavaScript - \
    "$CATALOG_PATH" "$WM_SLUG" "$SOURCE_SLUG" "$AUTO_SLUG" 2>&1 <<'JXA'
ObjC.import('Foundation');

function readUtf8(path) {
    const data = $.NSData.dataWithContentsOfFile(path);
    if (!data) throw new Error('无法读取模型目录：' + path);
    const string = $.NSString.alloc.initWithDataEncoding(data, $.NSUTF8StringEncoding);
    if (!string) throw new Error('模型目录不是有效的 UTF-8 文件。');
    return ObjC.unwrap(string);
}

function writeUtf8(path, text) {
    const string = $(text);
    const ok = string.writeToFileAtomicallyEncodingError(
        path,
        true,
        $.NSUTF8StringEncoding,
        null
    );
    if (!ok) throw new Error('无法写入自定义模型目录：' + path);
}

function run(argv) {
    const path = argv[0];
    const wmSlug = argv[1];
    const sourceSlug = argv[2];
    const autoSlug = argv[3];
    const catalog = JSON.parse(readUtf8(path));
    if (!Array.isArray(catalog.models)) throw new Error('模型目录缺少 models 数组。');

    const matches = catalog.models.filter(model => model && model.slug === wmSlug);
    if (matches.length > 1) throw new Error('发现多个 WM 条目，已中止。');

    const autoModel = catalog.models.find(model => model && model.slug === autoSlug);
    const autoVisibility = autoModel ? autoModel.visibility : null;
    let result;

    if (matches.length === 1) {
        matches[0].visibility = 'list';
        result = 'UNHIDDEN';
    } else {
        const sourceIndex = catalog.models.findIndex(model => model && model.slug === sourceSlug);
        if (sourceIndex < 0) throw new Error('找不到同系列模板：' + sourceSlug);

        const wmModel = JSON.parse(JSON.stringify(catalog.models[sourceIndex]));
        wmModel.slug = wmSlug;
        wmModel.display_name = 'GPT-5.6-Sol-WM';
        wmModel.description = 'Work Mode routing alias for GPT-5.6 Sol.';
        wmModel.visibility = 'list';
        wmModel.supported_in_api = false;
        wmModel.use_responses_lite = true;
        catalog.models.splice(sourceIndex + 1, 0, wmModel);
        result = 'ADDED';
    }

    if (autoModel && autoModel.visibility !== autoVisibility) {
        throw new Error('codex-auto-review 条目被意外改动。');
    }
    writeUtf8(path, JSON.stringify(catalog, null, 2) + '\n');
    return result;
}
JXA
)
jxa_status=$?
[ "$jxa_status" -eq 0 ] && \
    { [ "$jxa_output" = 'ADDED' ] || [ "$jxa_output" = 'UNHIDDEN' ]; } || \
    fail "更新自定义模型目录失败：$jxa_output"
if [ "$jxa_output" = 'ADDED' ]; then
    write_ok "$CATALOG_PATH（已从 $SOURCE_SLUG 克隆并新增 $WM_SLUG）"
else
    write_ok "$CATALOG_PATH（已有 WM 条目已设为 list）"
fi

if [ -n "$bundled_catalog" ]; then
    /bin/rm -f "$bundled_catalog" "$bundled_error"
fi

write_step '更新 config.toml'
config_backup="$CODEX_HOME_DIR/config.toml.before-wm-mac-$stamp.bak"
if [ -f "$CONFIG_PATH" ]; then
    /bin/cp -p "$CONFIG_PATH" "$config_backup" || fail '备份 config.toml 失败。'
else
    : > "$config_backup" || fail '创建空配置备份失败。'
fi

tmp_config=$(/usr/bin/mktemp "$CODEX_HOME_DIR/.config.toml.wm-enable.XXXXXX") || \
    fail '无法创建临时配置文件。'
trap 'rm -f "${tmp_config:-}"' EXIT

if [ -f "$CONFIG_PATH" ]; then
    input_config=$CONFIG_PATH
else
    input_config=/dev/null
fi

WM_MODEL_VALUE=$WM_SLUG \
WM_CATALOG_VALUE=$CATALOG_PATH \
/usr/bin/awk '
    function emit_missing() {
        if (!seen_model) print "model = \"" ENVIRON["WM_MODEL_VALUE"] "\""
        if (!seen_catalog) print "model_catalog_json = \"" ENVIRON["WM_CATALOG_VALUE"] "\""
        if (!seen_effort) print "model_reasoning_effort = \"max\""
    }
    BEGIN { in_top = 1 }
    in_top && /^[[:space:]]*\[/ {
        emit_missing()
        in_top = 0
    }
    in_top {
        line = $0
        sub(/^[[:space:]]*/, "", line)
        if (line ~ /^model[[:space:]]*=/) {
            if (!seen_model) print "model = \"" ENVIRON["WM_MODEL_VALUE"] "\""
            seen_model = 1
            next
        }
        if (line ~ /^model_catalog_json[[:space:]]*=/) {
            if (!seen_catalog) print "model_catalog_json = \"" ENVIRON["WM_CATALOG_VALUE"] "\""
            seen_catalog = 1
            next
        }
        if (line ~ /^model_reasoning_effort[[:space:]]*=/) {
            if (!seen_effort) print "model_reasoning_effort = \"max\""
            seen_effort = 1
            next
        }
    }
    { print }
    END { if (in_top) emit_missing() }
' "$input_config" > "$tmp_config" || fail '生成新 config.toml 失败。'

/bin/mv -f "$tmp_config" "$CONFIG_PATH" || fail '写入 config.toml 失败。'
trap - EXIT

config_model=$(top_level_line "$CONFIG_PATH" 'model' || true)
config_catalog=$(top_level_line "$CONFIG_PATH" 'model_catalog_json' || true)
config_effort=$(top_level_line "$CONFIG_PATH" 'model_reasoning_effort' || true)
[ "$config_model" = "model = \"$WM_SLUG\"" ] || fail '配置校验失败：model 未正确写入。'
[ "$config_catalog" = "model_catalog_json = \"$CATALOG_PATH\"" ] || \
    fail '配置校验失败：model_catalog_json 未正确写入。'
[ "$config_effort" = 'model_reasoning_effort = "max"' ] || \
    fail '配置校验失败：model_reasoning_effort 未正确写入。'
write_ok "config.toml 已写入：model = $WM_SLUG / reasoning = max"

printf '\n\033[32m========================================\033[0m\n'
printf '\033[32m 配置完成！\033[0m\n'
printf '\033[32m========================================\033[0m\n'
if /usr/bin/pgrep -x Codex >/dev/null 2>&1; then
    write_warn '检测到 Codex 正在运行。'
fi
printf '\033[36m已添加 %s。使用 Command-Q 完全退出 Codex，再重新打开。\033[0m\n' "$WM_SLUG"
printf '取消：  %s --remove\n' "$0"
